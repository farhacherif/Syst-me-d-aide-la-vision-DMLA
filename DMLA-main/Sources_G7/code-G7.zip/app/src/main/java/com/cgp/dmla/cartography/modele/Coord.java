package com.cgp.dmla.cartography.modele;
/**Class Coord qui contient les coordonnées d'un point et son intensité**/
public class Coord{

    public int x;
    public int y;
    public int intensity;

    /**Constructeur de la classe Coord qui initialise les coordonnées et l'intensité d'un point**/
    public Coord(int x1,int y1,int i){
        this.x=x1;
        this.y=y1;
        this.intensity=i;
    }
}