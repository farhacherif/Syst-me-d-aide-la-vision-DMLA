package com.cgp.dmla.showCartography.controlleur;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.cgp.dmla.R;
import com.cgp.dmla.cartography.modele.Memory;
import com.cgp.dmla.showCartography.vue.CartographyDraw;

public class CartographyDrawActivity extends AppCompatActivity {

    private CartographyDraw drawing;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_cartographydraw);
        ViewGroup myLayout = (ViewGroup) findViewById(R.id.mainLayout);

        // Get the screen WIDTH and HEIGHT to center the staticCircle
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        drawing = new CartographyDraw(this);
        Intent intent = getIntent();
        Memory memory = (Memory) intent.getSerializableExtra("memory");
        drawing.setMemory(memory);
        myLayout.addView(drawing);


    }
}
