package com.cgp.dmla.main.controlleur;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;

import com.cgp.dmla.R;
import com.cgp.dmla.SettingsActivity;
import com.cgp.dmla.showCartography.controlleur.CartographyDrawActivity;
import com.cgp.dmla.camera.controlleur.CameraActivity;
import com.cgp.dmla.cartography.controlleur.CartographyActivity;
import com.cgp.dmla.cartography.modele.Memory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {



    private static final int CAMERA_REQUEST_CODE = 1001;

    private int UserAge;

    private Button buttonCamera;
    private Button buttonNewCarto;
    private Button buttonShowCarto;
    private Button buttonPickCarto;

    private EditText txtAge;

    private Memory memory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPreferences", 0);

        //get language option
        Resources resources = getResources();
        Configuration configuration = resources.getConfiguration();
        final int languageOption = sharedPreferences.getInt("KEY_PREF_LANGUAGE", 0);
        switch (languageOption) {
            case 0:
                configuration.setLocale(new Locale("fr"));
                break;
            case 1:
                configuration.setLocale(new Locale("en"));
                break;
        }
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());


        //show help if first app use
        final int firstAppUse = sharedPreferences.getInt("firstAppUse", 0);
        if (firstAppUse==0) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.firstRun)
                    .setMessage(R.string.helpText)
                    .setPositiveButton(android.R.string.ok,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                    .create().show();
        }
        else{
            // Load cartography
            loadCartography();
        }

        //get User Age
        UserAge = sharedPreferences.getInt("UserAge", 0);

        //DarkMode verification
        final boolean DarkMode = sharedPreferences.getBoolean("DarkMode", false);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        if (firstAppUse==0)
            switch (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) {
                case Configuration.UI_MODE_NIGHT_YES:
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor.putInt("firstAppUse", 1);
                    editor.putBoolean("DarkMode", true);
                    editor.commit();
                    break;
                case Configuration.UI_MODE_NIGHT_NO:
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor.putInt("firstAppUse", 1);
                    editor.putBoolean("DarkMode", false);
                    editor.commit();
                    break;
            }
        else{
            if (DarkMode)
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            else
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }


        setContentView(R.layout.activity_main);

        buttonCamera = (Button) findViewById(R.id.buttonCamera);
        buttonNewCarto = (Button) findViewById(R.id.buttonNewCarto);
        buttonShowCarto = (Button) findViewById(R.id.buttonShowCarto);
        buttonPickCarto = (Button) findViewById(R.id.buttonPickCarto);

        buttonNewCarto.setOnClickListener(this);
        buttonCamera.setOnClickListener(this);
        buttonShowCarto.setOnClickListener(this);
        buttonPickCarto.setOnClickListener(this);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menu_settings)
        {
            final Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }
        if(id == R.id.menu_help)
        {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.help)
                    .setMessage(R.string.helpText)
                    .setPositiveButton(R.string.got_it,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                    .create().show();
        }
        if(id == R.id.menu_about)
        {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.about)
                    .setMessage(R.string.aboutText)
                    .setPositiveButton(R.string.close,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                    .create().show();
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View v) {
        final Intent[] intent = new Intent[1];
        SharedPreferences preferences = getSharedPreferences("MyPreferences", 0);

        switch (v.getId()){
            case R.id.buttonCamera :
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
                    return;
                }
                intent[0] = new Intent(this, CameraActivity.class);
                startActivity(intent[0]);
                break;
            case R.id.buttonNewCarto:
                Toast.makeText(this,"item selectionné",Toast.LENGTH_SHORT);

                int activityLaunchCount = 0;
                activityLaunchCount = preferences.getInt("ActivityLaunchCount", 0);
                SharedPreferences.Editor editor = preferences.edit();


                UserAge = preferences.getInt("UserAge", 0);
                if (UserAge == 0)
                {
                    activityLaunchCount = 1;
                    editor.putInt("ActivityLaunchCount", activityLaunchCount);

                    txtAge = new EditText(this);
                    txtAge.setHint(R.string.agePrompt);
                    txtAge.setInputType(InputType.TYPE_CLASS_NUMBER);

                    new AlertDialog.Builder(this)
                            .setTitle(R.string.firstRun)
                            .setMessage(R.string.agePrompt)
                            .setPositiveButton(android.R.string.ok,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if(txtAge.getText().toString().equals("") || txtAge.getText().toString().equals("0"))
                                            {
                                                //dialog.cancel();
                                            }
                                            else {

                                                UserAge = Integer.valueOf(txtAge.getText().toString());
                                                editor.putInt("UserAge", UserAge);
                                                editor.commit();
                                                intent[0] = new Intent(v.getContext(), CartographyActivity.class);
                                                startActivity(intent[0]);
                                            }
                                        }
                                    })
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            })
                            .setView(txtAge)
                            .create().show();
                }
                else {
                    intent[0] = new Intent(v.getContext(), CartographyActivity.class);
                    //System.out.println("LA_MEMOIRE " +  memory);
                    //Bundle bundle = new Bundle();
                    //bundle.putSerializable("memory",memory);
                    //intent[0].putExtras(bundle);
                    startActivity(intent[0]);

                }
                break;
            case R.id.buttonPickCarto :
                //intent[0] = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent[0] = new Intent(Intent.ACTION_GET_CONTENT);
                intent[0].addCategory(Intent.CATEGORY_OPENABLE);

                //("*/*") ("audio/ogg") ("image/png") ("video/*")
                intent[0].setType("*/*");
                startActivityForResult(intent[0], 10);
                //startActivity(intent[0]);
                break;
            case R.id.buttonShowCarto:
                String path = preferences.getString("cartoPath", "noPathSet");
                if(path.equals("noPathSet"))
                {
                    new AlertDialog.Builder(this)
                            .setTitle(R.string.no_carto_selected)
                            .setMessage(R.string.pick_carto_prompt)
                            .setPositiveButton(R.string.search,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //intent[0] = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                                            intent[0] = new Intent(Intent.ACTION_GET_CONTENT);
                                            intent[0].addCategory(Intent.CATEGORY_OPENABLE);

                                            //("*/*") ("audio/ogg") ("image/png") ("video/*")
                                            intent[0].setType("*/*");
                                            startActivityForResult(intent[0], 10);
                                            //startActivity(intent[0]);
                                        }
                                    })
                            .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            })
                            .create().show();
                }
                else
                {
                    loadCartography();
                    System.out.println(path);
                    // We start another intent
                    intent[0] = new Intent(v.getContext(), CartographyDrawActivity.class);
                    intent[0].putExtra("memory",memory);
                    startActivity(intent[0]);

                }
                //ici on a le path, reste plus qu'à afficher (mdr)
        }
    }

    private void loadCartography() {
        File[] files = this.getFilesDir().listFiles();
        if (files.length > 0) {
            String lastCartoName = files[files.length - 1].getName();
            SharedPreferences preferences = getSharedPreferences("MyPreferences", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("cartoPath", lastCartoName);
            editor.commit();
            this.memory = (Memory) readObjectFromFile(lastCartoName);
            this.memory.drawIt();
        }
    }

    public  Object readObjectFromFile(String filename) {

        ObjectInputStream objectIn = null;
        Object object = null;
        try {

            FileInputStream fileIn = this.openFileInput(filename);
            objectIn = new ObjectInputStream(fileIn);
            object = objectIn.readObject();

        } catch (FileNotFoundException e) {
            // Do nothing
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (objectIn != null) {
                try {
                    objectIn.close();
                } catch (IOException e) {
                    // do nowt
                }
            }
        }

        return object;
    }
    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        SharedPreferences preferences = getSharedPreferences("MyPreferences", 0);
        SharedPreferences.Editor editor = preferences.edit();

        String path = "noPathSet";
        switch(requestCode) {
            case 10:
                if(requestCode==10 && data!=null)
                    path = data.getData().getPath();
                break;
        }
        //editor.putString("cartoPath", path);
        editor.commit();
    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_REQUEST_CODE && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(this, CameraActivity.class);
            startActivity(intent);
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

}

