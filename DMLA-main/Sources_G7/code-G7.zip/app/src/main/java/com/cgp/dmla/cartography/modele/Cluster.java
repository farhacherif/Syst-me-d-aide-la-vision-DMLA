package com.cgp.dmla.cartography.modele;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;

import com.cgp.dmla.cartography.vue.CartographyView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Cluster {

    /* On suppose que la matrice est de dimension 10*10 */

    private List<Integer> areas;
    private Random random = new Random();
    private int width,height;


    /**
     * Constructeur de la classe Cluster, initialise width (respectivement height) comme étant le nombre de cercles qu'on peut mettre sur la largeur (resp. la hauteur).
     * On parcourt notre liste de rectangles afin de connaitre les positions des cercles qu'on va afficher à l'utilisateur.
     *
     *
     * @param height hauteur de l'écran
     * @param width largeur de l'écran
     * @param rects arrayList contenant des Rects pour delimiter les zones dans lesquelles on va afficher des points.
     */
    public Cluster(int height, int width, ArrayList<Rect> rects)
    {
        this.height = height/(2* CartographyView.DYNAMIC_RADIUS);
        this.width = width/(2* CartographyView.DYNAMIC_RADIUS);
        areas = new ArrayList<>();
        Iterator<Rect> iterator = rects.iterator();
        while (iterator.hasNext()) {

            Rect r = iterator.next();
            int maxWidth = r.right;
            int maxHeight = r.bottom;

            int startX = findNearestModulo(r.left,(CartographyView.DYNAMIC_RADIUS)*2);
            int startY = findNearestModulo(r.top,(CartographyView.DYNAMIC_RADIUS)*2);

            for (int y = startY ; y < maxHeight; y+= (2* CartographyView.DYNAMIC_RADIUS))
            {
                for (int x = startX ; x < maxWidth; x+= (2* CartographyView.DYNAMIC_RADIUS))
                {
                    Point real = getRealPoint(x,y);
                    int position = (this.width * real.y) + real.x;
                    areas.add(position);
                }
            }

        }

        Log.v("Cluster","width : "+this.width + "\nheight : "+this.height+"\n");
    }


    /**
     * L'algorithme se base sur l'idée qu'à chaque case de matrice (i,j) correspondent des coordonnées (x,y) sur l'écran.
     * Ainsi on peut passer de (x,y) à (i,j) comme on peut passer de (i,j) à (x,y).
     * Un problème se pose lorsqu'on essaye de convertir un (x,y) non 'attribué' en (i,j), c'est pour cela qu'on utilise la fonction findNearestModulo,
     * qui pour un (x1,y1) non attribués données retourne un (x,y) le plus proche attribué.
     * On l'exectue plutot pour x1 ensuite sur y1 et non pas les 2 en meme temps.
     *
     * @param current Le point non attribué
     * @param coeff  on cherche un point le plus proche de current dont le modulo par coeff est nul
     * @return le nouveau point proche de current et attribué
     */
    private int findNearestModulo(int current , int coeff)
    {
        double div = (double) current / coeff;
        double diff = div - (int) div;
        if (diff > 0.5){
            return (int)((div - diff)+1)*coeff;
        }
        return (int)((div - diff))*coeff;
    }


    /**
     * Choisit un élément au hasard en 0 et taille de la liste areas et une fois cet élément obtenu, on le transforme en un Point.
     * En résumé, c'est comme passé d'un index de tableau à des index de matrices.
     * Exemple : L'index 0 d'un tableau correpond à l'index (0,0) d'une matrice, etc
     *
     * @return un Point contenant des positions x et y aléatoires.
     */
    public Point getRandomPosition()
    {
        if (areas.size() == 0){
            return null;
        }
        System.out.println("Called again");
        int rand = random.nextInt(areas.size());
        int position = areas.get(rand);

        Point p = new Point();

        p.y =   position/this.width;
        p.x = position%this.width;
        // Pour avoir la position dans l'écran car les points [0][0] ne correspondent pas à la position 0,0 dans l'écran.
        p.y = (p.y*(2* CartographyView.DYNAMIC_RADIUS)) + CartographyView.DYNAMIC_RADIUS;
        p.x = (p.x*(2* CartographyView.DYNAMIC_RADIUS)) + CartographyView.DYNAMIC_RADIUS;
        System.out.println("SIZE :: " + this.areas.size());
        return p;
    }

    /**
     * Si on prend un Cercle dont les coordonnées dans la matrice sont (1,1), cela ne veut pas dire qu'on va afficher ce cercle aux positions 1,1 de l'ércan. Il faut
     * donc appliquer un calcul pour passer de coordonnées de matrice à coordonnées de l'écran.
     *
     * @param x int représentant la position selon la largeur.
     * @param y int représentant la position selon la hauteur.
     * @param radius int représentant le rayon d'un cercle
     * @return un Point correspondant aux coordonnées du point sur l'écran.
     */
    public static Point transformPoint(int x, int y,int radius)
    {
        Point pFinal = new Point();
        pFinal.y = (y*(2*radius)) + radius;
        pFinal.x = (x*(2*radius)) + radius;
        return pFinal;
    }

    /**
     * Permet de supprimer un élément de la liste areas.
     *
     * @param x position selon largeur
     * @param y position selon hauteur
     * @return True si la liste areas est vide et qu'il n y a donc plus de point à afficher, False sinon.
     */
    public boolean remove(int x, int y)
    {
        Point real = getRealPoint(x,y);
        int position = (this.width * real.y) + real.x;
        Integer i = new Integer(position);
        this.areas.remove(i);
        System.out.println("point (" +x+","+y+") removed !\nsize : "+this.areas.size() );
        return this.areas.size() > 0;
    }

    /**
     * Fonction inverse de transformPoint().
     * Permet d'obtenir les coordonnées matricielles d'un cercle à partir de ses coordonnées sur l'écran.
     *
     * @param x position selon largeur
     * @param y position selon hauteur
     * @return un Point contenant les coordonnées matricielles du cercle
     */
    public static Point getRealPoint(int x,int y)
    {
        int realX = (x - CartographyView.DYNAMIC_RADIUS)/(2* CartographyView.DYNAMIC_RADIUS);
        int realY = (y - CartographyView.DYNAMIC_RADIUS)/(2* CartographyView.DYNAMIC_RADIUS);

        Point p = new Point(realX,realY);
        return p;
    }

}
