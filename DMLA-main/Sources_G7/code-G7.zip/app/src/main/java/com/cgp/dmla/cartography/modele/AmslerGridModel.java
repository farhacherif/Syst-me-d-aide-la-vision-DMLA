package com.cgp.dmla.cartography.modele;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;

/**
 * Cette classe représente l'état de la grille d'Amsler.
 * Elle stocke les coordonnées des zones affichées à l'écran et aussi lesquelles parmi elles ont
 * été sélectionnées.
 */
public class AmslerGridModel {

    private int screenWidth, screenHeight;
    private int rows, columns, gap;
    private int areaSizeX, areaSizeY;
    private int nbAreasX, nbAreasY;
    private int verticalOffset, horizontalOffset;
    private boolean[][] selectedArea;
    private float[] lines;

    /**
     * Le contructeur de la classe AmslerGridModel.
     * @param width largeur de l'écran
     * @param height hauteur de l'écran
     * @param rows nombre de lignes dans la grille
     * @param columns nombre de colonnes dans la grille
     * @param areaSizeX nombre de colonnes dans une zone
     * @param areaSizeY nombre de lignes dans une zone
     */
    public AmslerGridModel(int width, int height, int rows, int columns, int areaSizeX, int areaSizeY) {
        screenWidth = width;
        screenHeight = height;
        this.rows = rows;
        this.columns = columns;
        this.areaSizeX = areaSizeX;
        this.areaSizeY = areaSizeY;
        init();
    }

    /**
     * L'initalisation des paramètres de la grille.
     * La méthode calcule le nombre de zones, l'espacement entre les lignes et le décalage initale.
     */
    private void init() {
        if (columns % 2 != 0 || rows % 2 != 0)
            throw new IllegalArgumentException("invalid number of columns for Amsler grid");
        if (columns % areaSizeX != 0 || rows % areaSizeY != 0)
            throw new IllegalArgumentException("invalid area size in Amsler grid");

        nbAreasX = columns/areaSizeX;
        nbAreasY = rows/areaSizeY;
        selectedArea = new boolean[nbAreasX][nbAreasY];

        gap = Math.min(screenWidth / columns, screenHeight / rows);
        horizontalOffset = (screenWidth - columns * gap) / 2;
        verticalOffset = (screenHeight - rows * gap) / 2;

        calculateLines();
    }

    /**
     * Calcule les coordonnées pour afficher les lignes qui forment la grille.
     */
    private void calculateLines() {
        lines = new float[4 * ((rows + 1) + (columns + 1))];
        int i = 0;
        for (int j = 0; j <= rows; j++) {
            lines[i++] = horizontalOffset;
            lines[i++] = verticalOffset + j * gap;
            lines[i++] = screenWidth - horizontalOffset;
            lines[i++] = verticalOffset + j * gap;
        }
        for (int j = 0; j <= columns; j++) {
            lines[i++] = horizontalOffset + j*gap;
            lines[i++] = verticalOffset;
            lines[i++] = horizontalOffset + j*gap;
            lines[i++] = screenHeight - verticalOffset;
        }

    }

    /**
     * Getter du tableau des zones sélectionnées.
     * @return tableau des zones sélectionnées
     */
    public boolean[][] getSelectedArea() {
        return selectedArea;
    }

    /**
     * Vérifie si une zone est sélectionnée
     * @param i colonne de la zone entre 0 et {@link AmslerGridModel#areaSizeX} (exclut)
     * @param j ligne de la zone entre 0 et {@link AmslerGridModel#areaSizeY} (exclut)
     * @return true si la zone a été sélectionnée, false sinon.
     */
    public boolean isAreaSelected(int i, int j) {
        return selectedArea[i][j];
    }

    /**
     * Renvoie le nombre de zones dans une ligne
     * @return nombre de zones dans une ligne
     */
    public int getNbAreasX() {
        return nbAreasX;
    }

    /**
     * Renvoie le nombre de zones dans une colonne
     * @return nombre de zones dans une colonne
     */
    public int getNbAreasY() {
        return nbAreasY;
    }

    /**
     * Renvoie le tableau qui contient toutes les lignes de la grille.
     *
     * Les 4 premières valeurs correspondent à la première ligne, les 4 suivantes - à la deuxième
     * ligne et ainsi de suite.
     *
     * Les 4 valeurs d'une ligne sont dans l'ordre : x1, y1, x2, y2.
     * @return tableau de toutes les lignes
     */
    public float[] getLines() {
       return lines;
    }

    /**
     * Renvoie le recteangle qui délimite une zone.
     * @param i colonne de la zone entre 0 et {@link AmslerGridModel#areaSizeX} (exclut)
     * @param j ligne de la zone entre 0 et {@link AmslerGridModel#areaSizeY} (exclut)
     * @return rectangle qui définit la zone
     */
    public Rect getAreaRect(int i, int j) {
        Rect r = new Rect();
        r.left = horizontalOffset + i*areaSizeX*gap;
        r.top = verticalOffset + j*areaSizeY*gap;
        r.right = r.left + areaSizeX*gap;
        r.bottom = r.top + areaSizeY*gap;
        return r;
    }

    /**
     * Renvoie le recteangle qui délimite une zone.
     *
     * La zone est déterminée à partir du point passé en paramètre.
     * La zone doit contenir ce point.
     * @param p point de l'écran
     * @return rectangle qui définit la zone
     */
    public Rect getAreaRect(Point p) {
        int areaX = getAreaX(p.x);
        int areaY = getAreaY(p.y);
        return getAreaRect(areaX, areaY);
    }

    /**
     * Renvoie la position du cercle au milieu
     * @return centre du cercle
     */
    public Point getDotPosition() {
        Point p = new Point();
        p.x = horizontalOffset + gap * columns / 2;
        p.y = verticalOffset + gap * rows / 2;
        return p;
    }

    /**
     * Renvoie le rayon du cercle du milieu
     * @return rayon du cercle
     */
    public float getDotRadius() {
        return (float) screenWidth / 80;
    }

    /**
     * Inverse la sélection d'une zone.
     *
     * La zone est définit par le point passé en paramètre.
     * La zone doit contenir ce point.
     * @param p point de l'écran
     */
    public void toggleAreaSelection(Point p) {
        int areaX = getAreaX(p.x);
        int areaY = getAreaY(p.y);
        if (areaX >= 0 && areaY >= 0) {
           selectedArea[areaX][areaY] = !selectedArea[areaX][areaY];
            Log.v("AmslerGridModel", "area (" + areaX + ", " + areaY + ") = "
                    + selectedArea[areaX][areaY]);
        }
    }

    /**
     * Transforme une coordonnée X en colonne de la zone à laquelle elle appartient.
     * @param x première composante d'un point
     * @return colonne de la zone (entre 0 et {@link AmslerGridModel#areaSizeX} (exclut))
     */
    private int getAreaX(int x) {
        if (x < horizontalOffset || x > horizontalOffset + columns * gap)
            return -1;
        return (x - horizontalOffset) / (areaSizeX * gap);
    }

    /**
     * Transforme une coordonnée Y en ligne de la zone à laquelle il appartient.
     * @param y deuxième composante d'un point
     * @return ligne de la zone (entre 0 et {@link AmslerGridModel#areaSizeY} (exclut))
     */
    private int getAreaY(int y) {
        if (y < verticalOffset || y > verticalOffset + rows * gap)
            return -1;
        return (y - verticalOffset) / (areaSizeY * gap);
    }

}
