package com.cgp.dmla.cartography.controlleur;

import android.content.Intent;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.os.ResultReceiver;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import com.cgp.dmla.R;
import com.cgp.dmla.cartography.modele.AmslerGridModel;
import com.cgp.dmla.cartography.vue.AmslerGridView;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Le controleur de la grille d'Amsler.
 * Cette classe utilise {@link AmslerGridModel} pour le modèle et
 * {@link AmslerGridView} pour la vue.
 */
public class AmslerGridActivity extends AppCompatActivity {

    public static final String RESULT_TAG = "rectList";
    private final int ROWS = 24;
    private final int COLS = 40;
    private final int AREA_X = 4;
    private final int AREA_Y = 4;
    private AmslerGridModel mGridModel;
    private AmslerGridView mGridView;

    /**
     * L'initialisation du controleur.
     * @param savedInstanceState bundle avec les paramètre de l'activité
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_amsler_grid);
        ViewGroup myLayout = (ViewGroup) findViewById(R.id.mainLayout);

        // Get the screen WIDTH and HEIGHT to center the staticCircle
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int widthPixels = displayMetrics.widthPixels;
        int heightPixels = displayMetrics.heightPixels;


        mGridModel = new AmslerGridModel(widthPixels, heightPixels, ROWS, COLS, AREA_X, AREA_Y);
        mGridView = new AmslerGridView(this, mGridModel);
        GestureDetectorCompat detectorCompat = new GestureDetectorCompat(this, new GestureListener());
        mGridView.setGestureDetector(detectorCompat);
        myLayout.addView(mGridView);
    }

    /**
     * Renvoie le résultat à l'activité appelante et quitte l'activité.
     *
     * Le résultat est une liste de rectangles sélectionnés par l'utilisateur.
     */
    public void returnResult() {
        ArrayList<Rect> rectList = new ArrayList<>();
        for (int i = 0; i < mGridModel.getNbAreasX(); i++) {
            for (int j = 0; j < mGridModel.getNbAreasY(); j++) {
                if (mGridModel.isAreaSelected(i, j)) {
                    rectList.add(mGridModel.getAreaRect(i, j));
                }
            }
        }
        if (rectList.size() == 0) {
            setResult(RESULT_CANCELED);
        }
        else {
            Intent intent = getIntent();
            intent.putParcelableArrayListExtra(RESULT_TAG, rectList);
            setResult(RESULT_OK, intent);
        }
        finish();
    }

    /**
     * Le listener de gestes qui distingue entre un click et un appui long
     */
    public class GestureListener extends GestureDetector.SimpleOnGestureListener {

        /**
         * Inverse la sélection de la zone.
         * @param e événement
         * @return true si l'événement a été traité, false sinon
         */
        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            Point point = new Point();
            point.x = (int) e.getX();
            point.y = (int) e.getY();
            Log.v("AmslerGrid", "tap on (" + point.x + "," + point.y + ")");
            mGridModel.toggleAreaSelection(point);
            mGridView.invalidate(mGridModel.getAreaRect(point));
            return true;
        }

        /**
         * Quitte l'activité et renvoie le résultat.
         * @param e événement
         * @param e
         */
        @Override
        public void onLongPress(MotionEvent e) {
            super.onLongPress(e);
            Log.v("AmslerGrid", "Long tap");
            returnResult();
        }
    }
}


