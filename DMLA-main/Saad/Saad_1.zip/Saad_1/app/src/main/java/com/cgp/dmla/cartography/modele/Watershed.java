package com.cgp.dmla.cartography.modele;

import androidx.core.util.Pair;

import java.util.LinkedList;

/**
 * Cette classe permet de délimiter les zones lésées de façon précise
 * à partir d'une image qui est sous forme de matrice
 */
public class Watershed {

    /**
     * Une image implémentée sous forme de matrice
     */
    private int[][] matrice;

    /**
     * Le gradient de 'matrice'
     */
    private int[][] matriceGradient;

    /**
     * L'image marqueurs de 'matrice'
     */
    private int[][] matriceMarkers;
    /**
     * La liste qui contient tous les pixels de l'image qu'il reste à traiter.
     * Pour plus de détailles du remplissage se référer à {@link Watershed#fillToProcess()}.
     */
    private LinkedList<LinkedList<Pair<Integer, Integer>>> toProcess;

    /**
     * Constructeur pour créer un objet Watershed et initialise les chmaps 'matrice' avec
     * une image passée sous forme de matrice en paramètre
     * et les champs 'matriceGradient' et 'matriceMarkers' avec des matrices d'entiers
     * @param matrice Une matrice contenant des informations sur une image
     */
    public Watershed(int[][] matrice) {
        this.matrice = matrice;
        matriceGradient = new int[matrice.length][matrice[0].length];
        matriceMarkers = new int[matrice.length][matrice[0].length];
        gradient();
        deduceMarkers();
    }

    public int[][] getWatershed() {
        computeWatershed();
        return matriceMarkers.clone();
    }

    public void setMatrice(int[][] matrice) {
        this.matrice = matrice;
        matriceGradient = new int[matrice.length][matrice[0].length];
        matriceMarkers = new int[matrice.length][matrice[0].length];
        gradient();
        deduceMarkers();
    }

    public void setMatriceMarkers(int[][] matriceMarkers) {
        this.matriceMarkers = matriceMarkers;
    }

    /**
     * Calcul le gradient d'une image
     */
    void gradient() {
        for (int i = 0; i < this.matrice.length; i++)
            for (int j = 0; j < this.matrice[0].length; j++)
                this.matriceGradient[i][j] = this.gradientLocalMax(i, j) - this.gradientLocalMin(i, j);
    }

    /**
     * Calcul le gradient local max d'un pixel (x,y) en prenant en compte les cases adjacentes
     * @param x Coordonnée x du pixel
     * @param y Coordonnée y du pixel
     * @return Renvoie le gradient local max autour d'un pixel (x,y)
     */
    private int gradientLocalMax(int x, int y) {
        int tmp = this.matrice[x][y];
        int k, l;

        k = Math.max(x - 1, 0);
        l = Math.max(y - 1, 0);

        for (int i = k; i <= x + 1 && i < this.matrice.length; i++)
            for (int j = l; j <= y + 1 && j < this.matrice[0].length; j++)
                if (this.matrice[i][j] > tmp)
                    tmp = this.matrice[i][j];

        return tmp;
    }

    /**
     * Calcul le gradient local min d'un pixel (x,y) en prenant en compte les cases adjacentes
     * @param x Coordonnée x du pixel
     * @param y Coordonnée y du pixel
     * @return Renvoie le gradient local min autour d'un pixel (x,y)
     */
    private int gradientLocalMin(int x, int y) {
        int tmp = this.matrice[x][y];
        int k, l;

        k = Math.max(x - 1, 0);
        l = Math.max(y - 1, 0);

        for (int i = k; i <= x + 1 && i < this.matrice.length; i++)
            for (int j = l; j <= y + 1 && j < this.matrice[0].length; j++)
                if (this.matrice[i][j] < tmp)
                    tmp = this.matrice[i][j];

        return tmp;
    }

    /**
     * Calcul l'image de marqueurs à partir d'une image
     */
    private void deduceMarkers() {
        int min = minMatrice(matrice);
        int max = maxMatrice(matrice);
        for (int i = 0; i < matrice.length; i++) {
            for (int j = 0; j < matrice[i].length; j++) {
                int k = Math.max(0, i-1);
                int l = Math.max(0, j-1);
                if (matrice[i][j] == min && (matrice[k][j] == min || matrice[i][l] == min))
                    matriceMarkers[i][j] = 1;
                if (matrice[i][j] == max && (matrice[k][j] == max || matrice[i][l] == max))
                    matriceMarkers[i][j] = 2;
            }
        }
    }

    /**
     * Calcul la ligne de partage des eaux d'une image afin de délimiter des zones dans une image
     */
    private void computeWatershed() {
        if (matriceGradient.length != matriceMarkers.length ||
                matriceGradient[0].length != matriceMarkers[0].length)
            throw new IllegalStateException("Gradient and markers have different sizes");
        int minGradient = minMatrice(matriceGradient);
        fillToProcess();
        Pair<Integer, Integer> pair = popFirstPair();
        int i, j, k, l;
        while (pair != null) {
            i = pair.first != null ? pair.first : 0;
            j = pair.second != null ? pair.second : 0;
            for (k = Math.max(0, i - 1); k <= i + 1 && k < matriceMarkers.length; k++) {
                for (l = Math.max(0, j - 1); l <= j + 1 && l < matriceMarkers[k].length; l++) {
                    if (matriceMarkers[k][l] == 0) {
                        matriceMarkers[k][l] = matriceMarkers[i][j];
                        toProcess.get(matriceGradient[k][l] - minGradient).push(Pair.create(k, l));
                    }
                }
            }
            pair = popFirstPair();
        }
    }

    /**
     * Renvoie le point ayant la valeur de gradient la moins élévée.
     * @return un pair d'entiers reptésentant un point
     */
    private Pair<Integer, Integer> popFirstPair() {
        for (LinkedList<Pair<Integer, Integer>> pairs : toProcess) {
            if (!pairs.isEmpty()) {
                return pairs.pop();
            }
        }
        return null;
    }

    /**
     * Remplie la liste toProcess.
     *
     * Pour chaque valeur de gradient on ajoute une nouvelle liste qui contiendra tous les points
     * ayant cette valeur de gradient.
     *
     * À la fin de la méthode la variable de toProcess contient tous les pixels de l'image
     * séparés en listes en fonction de leurs valeurs de gradient.
     * Les listes de toProcess sont triées selon la valeur de gradient en commençant par celle
     * qui a la valeur de gradient la plus petite.
     */
    private void fillToProcess() {
        int minGradient = minMatrice(matriceGradient);
        int maxGradient = maxMatrice(matriceGradient);
        int nbLevels = maxGradient - minGradient + 1;

        toProcess = new LinkedList<>();
        for (int i = 0; i < nbLevels; i++)
            toProcess.add(new LinkedList<>());

        for (int i = 0; i < matriceMarkers.length; i++) {
            for (int j = 0; j < matriceMarkers[i].length; j++) {
                if (matriceMarkers[i][j] != 0) {
                    Pair<Integer, Integer> pair = new Pair<>(i, j);
                    toProcess.get(matriceGradient[i][j] - minGradient).add(pair);
                }
            }
        }
    }

    /**
     * Cette fonction cherche le min d'une matrice
     * @param matrice Matrice de 2 dimensions d'entiers
     * @return Renvoie le min d'une matrice d'entiers
     */
    private int minMatrice(int[][] matrice) {
        int min = matrice[0][0];
        for (int[] ints : matrice) {
            for (int i : ints) {
                if (min > i) {
                    min = i;
                }
            }
        }
        return min;
    }

    /**
     * Cette fonction cherche le max d'une matrice
     * @param matrice Matrice de 2 dimensions d'entiers
     * @return Renvoie le max d'une matrice d'entiers
     */
    private int maxMatrice(int[][] matrice) {
        int max = matrice[0][0];
        for (int[] ints : matrice) {
            for (int i : ints) {
                if (max < i) {
                    max = i;
                }
            }
        }
        return max;
    }

}
