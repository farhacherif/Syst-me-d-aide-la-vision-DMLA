package com.cgp.dmla.cartography.vue;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;
import android.graphics.PointF;

import com.cgp.dmla.cartography.controlleur.CartographyActivity;

import java.util.Random;




public class CartographyView extends View {


    private Paint staticCirclePaint,dynamicCirclePaint,linesPaint;
    public static int STATIC_RADIUS, DYNAMIC_RADIUS;

    /**
     * Cerlce centrale sur lequel l'utilisateur concentre son regard
     */
    private Point staticCircle;
    /**
     * Cerlce dynamique qui bouge sur l'écran
     */
    private Point dynamicCircle;
    private int height = 0,width =0;
    public static final int HIDDEN_X=-100,HIDDEN_Y=-100;
    private Random random = new Random();
    private int[] intensities = {50,100,150,200,250}; //[0,50] [50,100] [100,150] [150,200] [200,255]


    public CartographyView(Context context) {
        super(context);
        init();
    }

    /*
     WIDTH : 72
     HEIGHT : 148
     */
    private void init() {

        width = CartographyActivity.WIDTH;
        height = CartographyActivity.HEIGHT;



        DYNAMIC_RADIUS = width/108;
        STATIC_RADIUS = width/18;


        staticCirclePaint = new Paint();
        staticCirclePaint.setColor(Color.RED);
        staticCirclePaint.setStyle(Paint.Style.STROKE);

        dynamicCirclePaint = new Paint();
        dynamicCirclePaint.setColor(Color.BLUE);
        dynamicCirclePaint.setStyle(Paint.Style.FILL);

        linesPaint = new Paint();
        linesPaint.setColor(Color.RED);
        linesPaint.setStyle(Paint.Style.FILL);

        staticCircle = new Point(HIDDEN_X,HIDDEN_Y);
        dynamicCircle = new Point(HIDDEN_X,HIDDEN_Y);

        System.out.println(" WIDTH : " + width/DYNAMIC_RADIUS);
        System.out.println(" HEIGHT : " + height/DYNAMIC_RADIUS);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawDynamicCircle(canvas);
        drawStaticCircle(canvas);
        drawLines(canvas);
    }

    /**
     * Fonction appelée pour obliger le canvas à redessiner, et donc à se mettre à jour
     */
    public void redraw() {
        this.invalidate();
    }

    /**
     * Trace le repère( + ) sur l'écran afin de fournir une meilleure précision à l'utilisateur
     *
     * @param canvas
     */
    private void drawLines(Canvas canvas) {
        canvas.drawLine(staticCircle.x,0,staticCircle.x,height+200,linesPaint);
        canvas.drawLine(0,staticCircle.y,width,staticCircle.y,linesPaint);
    }

    /**
     * Trace le cercle statique
     *
     * @param canvas
     */
    private void drawStaticCircle(Canvas canvas){
        canvas.drawCircle(staticCircle.x,staticCircle.y,STATIC_RADIUS,staticCirclePaint);
    }

    /**
     * Trace le cercle dynamique
     * @param canvas
     */
    private void drawDynamicCircle(Canvas canvas){
        canvas.drawCircle(dynamicCircle.x,dynamicCircle.y,DYNAMIC_RADIUS,dynamicCirclePaint);
    }


    /**
     * Getter
     * @return un Point correspondant aux coordonnées du cercle dynamique
     */
    public Point getDynamicCircle() {
        return dynamicCircle;
    }


    /**
     * Permet de fixer les positions (x,y) du cercle statique
     *
     * @param x
     * @param y
     */
    public void setStaticCircle(int x, int y) {
        this.staticCircle.x = x;
        this.staticCircle.y = y;
    }

    /**
     * Permet de fixer les positions (x,y) ainsi que l'intensité du cercle dynamique
     *
     * @param x
     * @param y
     */
    public void setDynamicCircle(int x, int y,int randomColor) {
        this.dynamicCirclePaint.setColor(Color.rgb(0,0,randomColor));
        this.dynamicCircle.x = x;
        this.dynamicCircle.y = y;
    }

    /**
     * Fonction qui retourne un entier compris entre 0 et 249, et en fonction de ce dernier détérmine quel élément du tableau intensities retourner
     *
     * @return un int , élément du tableau intensities
     */
    public int getIntensity() {
        int rand= random.nextInt(249);
        int index = rand/50;
        return intensities[index];
    }

}