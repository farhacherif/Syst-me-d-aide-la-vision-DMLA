package com.cgp.dmla.cartography.modele;

import android.graphics.Point;

import com.cgp.dmla.cartography.controlleur.CartographyActivity;
import com.cgp.dmla.cartography.vue.CartographyView;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;



public class Memory implements Serializable{
    private static final long serialVersionUID = 6529685098267757690L;
    private HashMap<Coord, Donnees> map;
    public int[][] fiabiliteArray;
    public static int MINIMUM = -1;
    public static int MAXIMUM = 1;
    private int height,width;

    private int dynamic_radius;


    public Memory() {
        map = new HashMap<>();
        this.height = CartographyActivity.HEIGHT/(2* CartographyView.DYNAMIC_RADIUS);
        this.width = CartographyActivity.WIDTH/(2*CartographyView.DYNAMIC_RADIUS);
        fiabiliteArray = new int[this.height][this.width];
    }

    /**
     * fonction qui prend en paramètre des coordonnées et une valeur (+1 pour point vu
     * et -1 pour point non vu) et l'insère dans la matrice de fiabilité et de d'index
     * dans la hashmap les coordonées, elle retourne la valeur maximal c'est-à-dire le nombre
     * maximum de fois que l'utilisateur peut répondre juste s'il voit le point MAXIMUM fois
     * MINIMUM si l'utilisateur ne voit pas le point MINIMUM fois,-1 sinon.
     * @param c
     * @param addedValue
     * @return int
     **/
    public int ajout(Coord c,int addedValue) {

        Point p = Cluster.getRealPoint(c.x,c.y);
        System.out.println("c : "+c.x + ":" + c.y);
        fiabiliteArray[c.y][c.x] = fiabiliteArray[c.y][c.x] + addedValue;
        int currentFiabilite = fiabiliteArray[c.y][c.x];
        System.out.println("("+c.y+","+c.x+") : "+ currentFiabilite);
        if (currentFiabilite == MINIMUM )
        {
            return MINIMUM;
        }
        else if (currentFiabilite == MAXIMUM)
        {
            return MAXIMUM;
        }
        else
        {
            return -1;
        }

    }
    /**
     * fonction qui utilise ajout et permet de savoir si un point a été vu MAXIMUM fois
     * ou n'a pas été vu MINIMUM fois dans ce cas elle retourne true sinon elle retourne false
     * @param x
     * @param y
     * @param intensite
     * @param seenIt
     * @return bool
     **/

    public boolean memoriser_reponse(int x, int y, int intensite,int seenIt) {

        Coord c = new Coord(x, y, intensite);
        int res = ajout(c,seenIt);
        return (res == MINIMUM || res == MAXIMUM);

    }
    /**
     * fonction qui affiche sur le terminal les points enregistrés, leurs intensité et leurs fiabilité
     **/
    public void printIt() {
        Set entrySet = map.entrySet();

        Iterator it = entrySet.iterator();


        while (it.hasNext()) {
            Map.Entry me = (Map.Entry) it.next();
            Coord c = (Coord) me.getKey();
            Donnees d = (Donnees) me.getValue();
            System.out.println("x:" + c.x + " y:" + c.y + " intensité:" + c.intensity);
            System.out.println("fiabilité: " + d.fiabilite + " nombre de fois:" + d.nb);
        }
    }
    /**
     * fonction qui affiche la matrice representant la fiabilité des points **/
    public void drawIt() {

        for (int i = 0; i < this.height ;i++) {
            for (int j = 0 ; j < this.width; j++) {
                if (fiabiliteArray[i][j] == MAXIMUM)
                    System.out.print("O");
                else
                    System.out.print("X");
            }
            System.out.println();
        }
    }

    public int getDynamic_radius() {
        return dynamic_radius;
    }

    public void setDynamic_radius(int dynamic_radius) {
        this.dynamic_radius = dynamic_radius;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}



