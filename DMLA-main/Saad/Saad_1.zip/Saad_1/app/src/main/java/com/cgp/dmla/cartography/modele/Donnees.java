package com.cgp.dmla.cartography.modele;

/**
 * Cette classe permet de créer des objets ayant une fiabilite
 */
public class Donnees {

    public int fiabilite;
    public int nb;


    public Donnees(int fiab, int nb){
        this.fiabilite=fiab;
        this.nb=nb;
    }
}
