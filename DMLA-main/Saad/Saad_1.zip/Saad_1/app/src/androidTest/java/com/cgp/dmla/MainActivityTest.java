package com.cgp.dmla;

import android.view.View;
import android.widget.Button;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import com.cgp.dmla.main.controlleur.MainActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.*;

public class MainActivityTest {

    @Rule
    public ActivityScenarioRule rule = new ActivityScenarioRule<>(MainActivity.class);

    private ActivityScenario scenario;

    @Before
    public void setUp() throws Exception {
        scenario = rule.getScenario();
    }

    @Test
    public void testLaunch() {
        scenario.onActivity(activity -> {


            View buttonCamera = activity.findViewById(R.id.buttonCamera);
            assertThat(buttonCamera, notNullValue());
            assertThat(buttonCamera, instanceOf(Button.class));

            View buttonNewCarto = activity.findViewById(R.id.buttonNewCarto);
            assertThat(buttonNewCarto, notNullValue());
            assertThat(buttonNewCarto, instanceOf(Button.class));

            View buttonPickCarto = activity.findViewById(R.id.buttonPickCarto);
            assertThat(buttonPickCarto, notNullValue());
            assertThat(buttonPickCarto, instanceOf(Button.class));

            View buttonShowCarto = activity.findViewById(R.id.buttonShowCarto);
            assertThat(buttonShowCarto, notNullValue());
            assertThat(buttonShowCarto, instanceOf(Button.class));


        });
    }

    @After
    public void tearDown() throws Exception {
        scenario = null;
    }
}