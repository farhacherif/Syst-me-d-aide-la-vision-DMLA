package com.cgp.dmla;

import android.view.View;

import androidx.camera.view.PreviewView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import com.cgp.dmla.camera.controlleur.CameraActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class CameraActivityTest {

    @Rule
    public ActivityScenarioRule rule = new ActivityScenarioRule<>(CameraActivity.class);

    private ActivityScenario scenario;

    @Before
    public void setUp() throws Exception {
        scenario = rule.getScenario();
    }

    @Test
    public void testLaunch() {
        scenario.onActivity(activity -> {

            View cameraView = activity.findViewById(R.id.previewViewCamera);
            assertThat(cameraView, notNullValue());
            assertThat(cameraView, instanceOf(PreviewView.class));

        });
    }

    @After
    public void tearDown() throws Exception {
        scenario = null;
    }
}