package com.cgp.dmla.cartography.controlleur;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.app.Activity;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

import com.cgp.dmla.cartography.modele.Cluster;
import com.cgp.dmla.cartography.modele.Memory;
import com.cgp.dmla.cartography.vue.CartographyView;
import com.cgp.dmla.R;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class CartographyActivity extends AppCompatActivity {

    private CartographyView drawing;
    Point dynamicCircle;
    public static int HEIGHT,WIDTH;
    private Random random = new Random();
    private Handler handler = new Handler();
    private final int TIMEOUT = 100;
    private final int EXTRA_TIME = 3000;
    private final int RESPONSE_TIME = 1000;
    private int currentX, currentY;
    private int currentIntensity;
    private Boolean keepGoing = true;
    Date drawDate;
    Memory memory;
    Cluster cluster;
    private final int AMSLER_REQUEST_CODE = 21;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_cartography);
        ViewGroup myLayout = (ViewGroup) findViewById(R.id.mainLayout);

        // Get the screen WIDTH and HEIGHT to center the staticCircle
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        HEIGHT = displayMetrics.heightPixels;
        WIDTH = displayMetrics.widthPixels;

        drawing = new CartographyView(this);
        memory = new Memory();


        //Bundle bundle = getIntent().getExtras();
        //Intent i = getIntent();
        //memory = (Memory) i.getSerializableExtra("memory");

        memory.setDynamic_radius(drawing.DYNAMIC_RADIUS);

        myLayout.addView(drawing);

        drawing.setStaticCircle(WIDTH/2,HEIGHT/2);
        dynamicCircle = drawing.getDynamicCircle();

        Intent intent = new Intent(this, AmslerGridActivity.class);
        startActivityForResult(intent, AMSLER_REQUEST_CODE);

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AMSLER_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<Rect> rects = data.getParcelableArrayListExtra(AmslerGridActivity.RESULT_TAG);
                cluster = new Cluster(HEIGHT, WIDTH, rects);
                start(EXTRA_TIME, true);
            }
            else if (resultCode == RESULT_CANCELED) {
                finish();
            }
        }
    }


    /**
     *
     * Fonction principale, elle s'appelle elle meme en affichant à chaque fois un cercle au hasard sur l'écran jusqu'à ce qu'il n y ait plus de cercle à afficher.
     *
     * @param timeout temps au bout duquel la fonction start s'execute
     * @param show boolean qui précise si on affiche un cercle ou pas
     */
    public void start(int timeout,Boolean show) {

        handler.postDelayed(() ->
        {
            if (keepGoing) {
                if (show) {
                    if (drawDate != null) {
                        long diff = getDeltaTime();
                        updateMemory(diff, false);
                    }
                    if (keepGoing) {
                        //Point pos = getNextPoint();
                        Point pos = cluster.getRandomPosition();

                        int randomColor = drawing.getIntensity();


                        drawing.setDynamicCircle(pos.x, pos.y, randomColor);
                        currentX = pos.x;
                        currentY = pos.y;
                        currentIntensity = randomColor;
                        drawing.redraw();
                        drawDate = new Date();
                        String message = "point (" + currentX + ", " + currentY + ") showed";
                        Log.v("CartographyActivity", message);
                        start(TIMEOUT, false);
                    }

                } else {

                    String message = "stop showing point (" + currentX + ", " + currentY + ")";
                    Log.v("CartographyActivity", message);
                    drawing.setDynamicCircle(CartographyView.HIDDEN_X, CartographyView.HIDDEN_Y, 0);
                    drawing.redraw();
                    int nextPointTimeout = random.nextInt(EXTRA_TIME) + RESPONSE_TIME;
                    start(nextPointTimeout, true);

                }
            }

        }, timeout);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        keepGoing = false;
    }

    /**
     * Fonction qui capture un événement et met à jour la mémoire
     *
     * @param event événement qui a déclenché cette fonction
     * @return Boolean
     */
    @Override
    public boolean dispatchKeyEvent(@NotNull KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN || event.getKeyCode() == KeyEvent.KEYCODE_DPAD_CENTER) && drawDate != null) {
                Log.v("CartographyActivity", "center button pressed");
                long diff = getDeltaTime();
                updateMemory(diff,true);
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private long getDeltaTime() {
        Date end = new Date();
        return end.getTime() - drawDate.getTime() ;
    }

    /**
     * sauvegarde la cartographie et met fin à l'activité
     */
    private void quit() {
        memory.drawIt();
        // We must first know the number that will be given to the new cartography
        int cartoNumber = getCartoNum();
        // Here we save the memory object in a file
        this.writeObjectToFile(this.memory,"cartography"+cartoNumber);
        finishAndRemoveTask();
    }

    /**
     * Incremente ou décrémente de 1 la fiabilité du cercle dans la mémoire et met à jour la variable keepgoing qui permet de determiner si on a encore des points à afficher.
     *
     * @param diff le temps écoulé depuis l'affichage du dernier cercle
     * @param clicked Boolean qui montre si l'utilisateur a cliqué ou pas
     */
    private void updateMemory(long diff,Boolean clicked) {
        Point p = cluster.getRealPoint(currentX,currentY);
        String message = "updateMemory called with:\n\ttime delay: " + diff
                + "\n\tclicked: " + clicked
                + "\n\tpoint: (" + currentX + ", " + currentY + ")";
        Log.v("CartographyActivity", message);
        if (diff < RESPONSE_TIME ){
            if (clicked){
                if (memory.memoriser_reponse(p.x,p.y,currentIntensity,1))
                {
                    keepGoing = cluster.remove(currentX,currentY);
                }
            }
        }
        else {
            if (memory.memoriser_reponse(p.x,p.y,currentIntensity,-1))
            {
                keepGoing = cluster.remove(currentX,currentY);
            }
        }
        drawDate = null;
        if (!keepGoing) {
            quit();
        }

    }

    /**
     * Permet d'enregister un objet dans un fichier
     *
     * @param object L'objet qu'on va enregistrer dans un fichier
     * @param filename le nom du fichier dans lequel on va enregistrer l'objet
     */
    private void writeObjectToFile( Object object, String filename) {
        File[] files = this.getFilesDir().listFiles();
        for (File f:files){
            System.out.println(f.getAbsoluteFile());
        }
        //System.out.println(this.getFilesDir().listFiles());
        ObjectOutputStream objectOut = null;
        try {

            FileOutputStream fileOut = this.openFileOutput(filename, Activity.MODE_PRIVATE);
            objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(object);
            fileOut.getFD().sync();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (objectOut != null) {
                try {
                    objectOut.close();
                } catch (IOException e) {
                    // whatever
                }
            }
        }
    }

    /**
     * Détermine le numéro qu'on va attribuer à la cartographie
     *
     * @return Le numéro de la dernière cartographie enregistrée + 1
     */
    private int getCartoNum(){
        return this.getFilesDir().listFiles().length + 1;
    }

}

