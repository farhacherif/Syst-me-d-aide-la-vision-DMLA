package com.cgp.dmla;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

import com.cgp.dmla.main.controlleur.MainActivity;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;


public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setTitle(R.string.title_activity_settings);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings_container, new MySettingsFragment())
                .commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static class MySettingsFragment extends PreferenceFragmentCompat {
        private SwitchPreferenceCompat darkModeSwitch;
        private EditTextPreference userAgeInput;
        private ListPreference languageSelect;

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.pref_main, rootKey);

            SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("MyPreferences", 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();



            darkModeSwitch = findPreference("darkmode");

            final boolean DarkMode = sharedPreferences.getBoolean("DarkMode", false);
            if (!DarkMode)
                darkModeSwitch.setChecked(false);
            else
                darkModeSwitch.setChecked(true);


            darkModeSwitch.setOnPreferenceChangeListener((preference, newValue) -> {
                boolean isOn = (Boolean) newValue;
                SwitchPreferenceCompat darkModeSwitch = (SwitchPreferenceCompat) preference;
                if(!DarkMode)
                    {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                        editor.putBoolean("DarkMode", true);
                        darkModeSwitch.setChecked(true);
                    }
                else
                    {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                        editor.putBoolean("DarkMode", false);
                        darkModeSwitch.setChecked(false);
                    }
                editor.commit();
                return true;
            });




            userAgeInput = findPreference("UserAge");
            userAgeInput.setOnBindEditTextListener(editText -> editText.setInputType(InputType.TYPE_CLASS_NUMBER));

            //maybe getString au lieu de getInt
            final int[] UserAge = {sharedPreferences.getInt("UserAge", 0)};

            if (UserAge[0] != 0)
                userAgeInput.setSummary(String.valueOf(UserAge[0]));
            else
                userAgeInput.setSummary(R.string.not_set);


            userAgeInput.setOnPreferenceChangeListener((preference, newValue) -> {

                new AlertDialog.Builder(this.getContext()).setTitle(R.string.save)
                                .setPositiveButton(android.R.string.yes,
                                        new DialogInterface.OnClickListener() {
                                            EditTextPreference userAgeInput = (EditTextPreference) preference;
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                String age = userAgeInput.getText();
                                                if(!"".equals(age))
                                                    UserAge[0] = Integer.parseInt(age);
                                                else
                                                    UserAge[0] = 0;
                                                editor.putInt("UserAge", UserAge[0]);
                                                editor.apply();
                                                if (UserAge[0] == 0)
                                                    userAgeInput.setSummary(R.string.not_set);
                                                else
                                                    userAgeInput.setSummary(String.valueOf(UserAge[0]));
                                            }
                                        })
                                .setNegativeButton(android.R.string.no,
                                        new DialogInterface.OnClickListener() {
                                            EditTextPreference userAgeInput = (EditTextPreference) preference;
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (UserAge[0] == 0)
                                                    userAgeInput.setSummary(R.string.not_set);
                                                else
                                                    userAgeInput.setSummary(String.valueOf(UserAge[0]));
                                                dialog.cancel();
                                            }
                                        })
                                .create().show();
                return true;
            });







            languageSelect = findPreference("Langue");

            final int listIndexValue = sharedPreferences.getInt("KEY_PREF_LANGUAGE", 0);
            languageSelect.setValueIndex(listIndexValue);
            final int[] newListIndexValue = {0};

            languageSelect.setOnPreferenceChangeListener((preference, newValue) -> {
                switch (newValue.toString()) {
                    case "Français":
                        newListIndexValue[0] = 0;
                        break;
                    case "Anglais":
                        newListIndexValue[0] = 1;
                        break;
                }
                editor.putInt("KEY_PREF_LANGUAGE", newListIndexValue[0]);
                editor.commit();


                Context context = this.getContext();
                if (newListIndexValue[0] != listIndexValue) {
                    new AlertDialog.Builder(context)
                            .setTitle(R.string.reboot)
                            .setPositiveButton(android.R.string.ok,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            triggerRebirth(context, new Intent());
                                        }
                                    })
                            .setNegativeButton(R.string.later,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //languageSelect.setValueIndex(listIndexValue);
                                            dialog.cancel();
                                        }
                                    })
                            .create().show();
                    return true;
                }
                else{
                    return true;
                }
            });
        }
    }


    /**
     * Cette fonction permet de redémarrer l'application
     * @param context Permet de récupérer des informations sur le système
     * @param nextIntent Définit l'activité à lancer lors du redémarrage
     */
    public static void triggerRebirth(Context context, Intent nextIntent) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(FLAG_ACTIVITY_NEW_TASK);
        //intent.putExtra(KEY_RESTART_INTENT, nextIntent);
        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity) context).finish();
        }

        Runtime.getRuntime().exit(0);
    }


}

