package com.cgp.dmla.cartography.vue;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.view.GestureDetectorCompat;

import com.cgp.dmla.cartography.modele.AmslerGridModel;

/**
 * La vue d'Amsler Grid.
 */
public class AmslerGridView extends View {

    private final float LINE_WIDTH = 4f;
    private Paint linesPaint;
    private Paint areaLinesPaint;
    private Paint dotPaint;
    private Paint selectionPaint;
    private AmslerGridModel gridModel;
    private GestureDetectorCompat gestureDetector;

    /**
     * Constructeur de AmslerGridView.
     *
     * @param context contexte de la vue
     * @param model modèle de grille d'Amsler
     */
    public AmslerGridView(Context context, AmslerGridModel model) {
        super(context);
        gridModel = model;

        linesPaint = new Paint();
        linesPaint.setColor(Color.BLACK);
        linesPaint.setStrokeWidth(LINE_WIDTH);

        areaLinesPaint = new Paint();
        areaLinesPaint.setColor(Color.BLACK);
        areaLinesPaint.setStrokeWidth(2 * LINE_WIDTH);
        areaLinesPaint.setStyle(Paint.Style.STROKE);

        dotPaint = new Paint();
        dotPaint.setColor(Color.BLACK);
        dotPaint.setStyle(Paint.Style.FILL);

        selectionPaint = new Paint();
        selectionPaint.setColor(Color.YELLOW);
        selectionPaint.setStyle(Paint.Style.FILL);
    }

    /**
     * Dessine la grille.
     * @param canvas toile
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        setBackgroundColor(Color.WHITE);
        drawAreas(canvas);
        drawLines(canvas);
        drawDot(canvas);
    }

    /**
     * Dessine les zones.
     *
     * Toutes les zones ont un bord plus épais.
     * Les zones sélectionnées ont une couleur de fond différente.
     * @param canvas toile
     */
    private void drawAreas(Canvas canvas) {
        for (int i = 0; i < gridModel.getNbAreasX(); i++) {
            for (int j = 0; j < gridModel.getNbAreasY(); j++) {
                Rect area = gridModel.getAreaRect(i, j);
                if (gridModel.isAreaSelected(i, j)) {
                    canvas.drawRect(area, selectionPaint);
                }
                canvas.drawRect(area, areaLinesPaint);
            }
        }
    }

    /**
     * Dessine les lignes de la grille.
     * @param canvas toile
     */
    private void drawLines(Canvas canvas) {
        canvas.drawLines(gridModel.getLines(), linesPaint);
    }

    /**
     * Dessine le cercle du milieu.
     * @param canvas toile
     */
    private void drawDot(Canvas canvas) {
        Point p = gridModel.getDotPosition();
        canvas.drawCircle(p.x, p.y , gridModel.getDotRadius(), dotPaint);
    }

    /**
     * Setters pour le détecteur de gestes.
     * @param detector détecteur de gestes
     */
    public void setGestureDetector(GestureDetectorCompat detector) {
        gestureDetector = detector;
    }

    /**
     * Transmet l'événement d'appui au détecteur de gestes.
     * @param event événement à transmettre
     * @return true si l'événement a été traité, false sinon
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return true;
    }
}
