package com.cgp.dmla.showCartography.vue;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.View;

import com.cgp.dmla.cartography.modele.Cluster;
import com.cgp.dmla.cartography.modele.Memory;

public class CartographyDraw extends View {

    private Paint seeCircle,nseeCircle;
    private Memory memory;

    public CartographyDraw(Context context) {
        super(context);
        seeCircle = new Paint();
        seeCircle.setColor(Color.BLUE);
        seeCircle.setStyle(Paint.Style.FILL);

        nseeCircle = new Paint();
        nseeCircle.setColor(Color.parseColor("#6603DAC5"));
        nseeCircle.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for( int i = 0 ; i < memory.getHeight() ; i++)
        {
            for ( int j = 0; j < memory.getWidth() ; j++)
            {
                Point p = Cluster.transformPoint(i,j,memory.getDynamic_radius());
                if (memory.fiabiliteArray[i][j] == memory.MAXIMUM || memory.fiabiliteArray[i][j] != 0){
                    canvas.drawCircle(p.y,p.x,memory.getDynamic_radius(),nseeCircle);
                }

            }
        }
    }

    public void setMemory(Memory memory) {
        this.memory = memory;
    }
}
