package com.cgp.dmla;

import android.graphics.Point;
import android.graphics.Rect;

import com.cgp.dmla.cartography.modele.Cluster;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class ClusterTest {

    @Test
    public void transformPointTest() {
        Point expected= new Point(1,1);
        int radius = 10;
        int x1= (int)((1- radius)/2*radius);
        int y1= (int)((1- radius)/2*radius);
        Point c=new Point(x1,y1);
        ArrayList<Rect> r = new ArrayList<>();
        Cluster cl= new Cluster(10/*la taille*/,10/*la largeur*/,r);

        assertEquals(expected,cl.transformPoint(c.x,c.y,radius));
    }

    @Test
    public void removeTest() {
        ArrayList<Rect> r = new ArrayList<>();
        Cluster cl = new Cluster(10/*taille*/,10 /*largeur*/,r);
        cl.remove(1,1);
        //on s'attend a voir true qui sera modélisé par le double 2 (pb junit on peut comparer que double et pas de int ni de bool)
        double k=(cl.remove(1, 1)) ? 2.0 : 1.0;
        double expected = 2.0;
        assertEquals(expected,k,0);

    }



}
