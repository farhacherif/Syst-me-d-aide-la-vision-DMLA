package com.cgp.dmla;

import com.cgp.dmla.cartography.modele.Watershed;

import org.junit.Test;

import static org.junit.Assert.*;

public class WatershedTest {

    @Test
    public void watershedComputing() {
        int[][] image = {{1,1,1},{2,2,2},{4,4,4}};
        int[][] expectedWatershed = {{1,1,1},{1,1,1},{2,2,2}};
        Watershed watershed = new Watershed(image);
        int[][] w = watershed.getWatershed();
        assertArrayEquals(expectedWatershed, w);
    }

    @Test
    public void watershedComputing2() {
        int[][] image = {{1,4,4},{1,4,5},{1,4,5}};
        int[][] expectedWatershed = {{1,2,2},{1,2,2},{1,2,2}};
        Watershed watershed = new Watershed(new int[1][1]);
        watershed.setMatrice(image);
        int[][] w = watershed.getWatershed();
        assertArrayEquals(expectedWatershed, w);
    }

    @Test
    public void watershedComputing3() {
        int[][] image = {{-1,-1,-1},{1,1,1},{2,1,2}};
        int[][] expectedWatershed = {{1,1,1},{2,2,2},{2,2,2}};
        Watershed watershed = new Watershed(new int[1][1]);
        watershed.setMatrice(image);
        int[][] w = watershed.getWatershed();
        assertArrayEquals(expectedWatershed, w);
    }

    @Test
    public void wrongMatrix() {
        int[][] image = {{2,3},{1,2}};
        int[][] mark = {{1,0,0},{0,0,0},{0,0,2}};
        Watershed watershed = new Watershed(image);
        watershed.setMatriceMarkers(mark);
        RuntimeException exception = assertThrows(RuntimeException.class, watershed::getWatershed);
        String message = exception.getMessage();
        assertNotNull(message);
        assertTrue(message.contains("size"));
    }

}
