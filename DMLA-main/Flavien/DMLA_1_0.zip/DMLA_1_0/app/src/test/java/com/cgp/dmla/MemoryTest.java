package com.cgp.dmla;

import com.cgp.dmla.cartography.modele.Coord;
import com.cgp.dmla.cartography.modele.Memory;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class MemoryTest {

    @Test
    public void ajoutTest() {
        Memory m= new Memory();
        //Pour un point qui est fiable
        double expectedajout = 0.5;
        Coord c= new Coord(1,1,4);
        double w=m.ajout(c,0);
        assertEquals(expectedajout,w,0 );
    }

    @Test
    public void memoriser_reponseTest() {
        Memory m= new Memory();
        //on cast de bool à int
        double b=(m.memoriser_reponse(1,
                1,
                1,
                0)) ? 2.0 : 1.0;
        double expected = 2.0;
        assertEquals(expected,b,0 );

    }



}
