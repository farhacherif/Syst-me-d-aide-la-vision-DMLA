package com.cgp.dmla;

import android.view.View;
import android.view.ViewGroup;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import com.cgp.dmla.cartography.controlleur.CartographyActivity;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class CartographyActivityTest {

    @Rule
    public ActivityScenarioRule rule = new ActivityScenarioRule<>(CartographyActivity.class);

    private ActivityScenario scenario;

    @Before
    public void setUp() throws Exception {
        scenario = rule.getScenario();
    }

    @Test
    public void testLaunch() {
        scenario.onActivity(activity -> {

            View myView = activity.findViewById(R.id.mainLayout);
            assertThat(myView, notNullValue());
            assertThat(myView, instanceOf(ViewGroup.class));

        });
    }

    @After
    public void tearDown() throws Exception {
        scenario = null;
    }
}