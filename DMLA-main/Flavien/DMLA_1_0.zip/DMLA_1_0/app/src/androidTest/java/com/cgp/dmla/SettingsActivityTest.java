package com.cgp.dmla;

import android.view.View;
import android.widget.FrameLayout;

import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.SwitchPreferenceCompat;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SettingsActivityTest {

    @Rule
    public ActivityScenarioRule rule = new ActivityScenarioRule<>(SettingsActivity.class);

    private ActivityScenario scenario;

    @Before
    public void setUp() throws Exception {
        scenario = rule.getScenario();
    }

    @Test
    public void testLaunch() {
        scenario.onActivity(activity -> {

            View settingsLayout = activity.findViewById(R.id.settings_container);
            assertThat(settingsLayout, notNullValue());
            assertThat(settingsLayout, instanceOf(FrameLayout.class));

            View userAge = settingsLayout.findViewById(R.id.UserAge);
            assertThat(userAge, notNullValue());
            assertThat(userAge, instanceOf(EditTextPreference.class));

            View language = settingsLayout.findViewById(R.id.Langue);
            assertThat(language, notNullValue());
            assertThat(language, instanceOf(ListPreference.class));

            View darkMode = settingsLayout.findViewById(R.id.darkmode);
            assertThat(darkMode, notNullValue());
            assertThat(darkMode, instanceOf(SwitchPreferenceCompat.class));

        });
    }

    @After
    public void tearDown() throws Exception {
        scenario = null;
    }
}